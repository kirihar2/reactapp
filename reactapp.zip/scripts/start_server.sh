    
#!/bin/bash
npm start --prefix=/home/ec2-user/react

