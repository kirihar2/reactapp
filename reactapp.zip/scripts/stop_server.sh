#!/bin/bash
service react-app stop
