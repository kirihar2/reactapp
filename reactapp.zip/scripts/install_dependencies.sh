    
#!/bin/bash
sudo yum install -y npm
